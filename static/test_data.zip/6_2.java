package connection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.*;
import java.lang.*;
public class server {

Socket s;
ServerSocket ss;
InputStream in;
OutputStream out;
    
BufferedReader br=new BufferedReader(new InputStreamReader(System.in) {
        
@Override
public int read() throws IOException {// TODO Auto-generated method stub
            return 0;   }
    });
public server() {   // TODO Auto-generated constructor stub
        try {   ss=new ServerSocket(1000);  } 
catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
    }
void doEcho() throws IOException
        {
            int ch=0;
            int t=0;
            s=ss.accept();
            in=s.getInputStream();
            out=s.getOutputStream();
            
            while((ch=in.read())!=(-1))
            {
                System.out.print((char)ch);
                out.write(ch);
                //System.out.println("");
            }
            
    boolean flag=true;
    while(flag)
    {
    try {   t=br.read();//To read users input}
 catch (IOException e) {// TODO Auto-generated catch block
                    e.printStackTrace();    }
    if(t=='x')  {break;}
    try {   out.write(t);//TO write to server's console } 
catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();}
        try {   in.read(); //To read server's response  }
 catch (IOException e) {// TODO Auto-generated catch block
            e.printStackTrace();}
            }
        }
        public static void main(String args[]) throws IOException
        {
            server soc= new server();
            soc.doEcho();
        }
    }   