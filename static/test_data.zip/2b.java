package swing;

import java.awt.Container;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class salary  
{
    public static void main(String s[])
    {
        count c1=new count();
        c1.setVisible(true);
    }
}

class count extends JFrame implements ActionListener
{
    JLabel l1,l2,l3,l4,l5;
    JTextField t1,t2,t3,t4,t5,total1;
    JButton b1;
    Container c;
    JPanel p1;
    count()
    {
        c=new Container();setSize(500,500);
        p1=new JPanel();
        b1=new JButton("TOTAL");
        l1=new JLabel("SALARY");l2=new JLabel("HRA");l3=new JLabel("DA");
        l4=new JLabel("MEDICAL");l5=new JLabel("OTHER");
        t1=new JTextField(10);t2=new JTextField(10);t3=new JTextField(10);
        t4=new JTextField(10);t5=new JTextField(10);total1=new JTextField(10);
        setLayout(new GridLayout(6,2));
        add(l1);add(t1);add(l2);add(t2);add(l3);add(t3);
        add(l4);add(t4);add(l5);add(t5);add(b1);add(total1);
        c.add(p1);
        b1.addActionListener(this);
    }
    
        @Override
    public void actionPerformed(ActionEvent arg0) {
        // TODO Auto-generated method stub
        String str=arg0.getActionCommand();
        double ans=0;
        double a,b,c,d,e;
         if(t1.getText()!= "" && t2.getText() != "" && t3.getText() != "" && t4.getText() != "" && t5.getText() != "")
         {
             a = Integer.parseInt(t1.getText());
             b = a*(.50);   System.out.println(b);  t2.setText(Integer.toString((int) b));
             c = a*(.35);   System.out.println(c);  t3.setText(Integer.toString((int) c));
             d = a*(.25);   System.out.println(d);  t4.setText(Integer.toString((int) d));
             e = a*(.11);   System.out.println(e);  t5.setText(Integer.toString((int) e));
             ans = a+b+c+d+e;
             System.out.println(ans);
                total1.setText(Integer.toString((int) ans));
         }
    }
}