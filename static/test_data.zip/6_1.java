package connection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.*;

public class client {

Socket s;
InputStream is;
OutputStream os;
BufferedReader br=new BufferedReader(new InputStreamReader(System.in) {
        
@Override
public int read() throws IOException {  return 0;   }
});
client()
{
        // TODO Auto-generated constructor stub
        try {
            s=new Socket("127.0.0.1",1000);
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
}
    
void doEcho() throws IOException
{
int ch=0;
try {
is=s.getInputStream();
} 
catch (IOException e) 
{// TODO Auto-generated catch block
    e.printStackTrace();        }
    try {   os=s.getOutputStream();}
catch (IOException e) {// TODO Auto-generated catch block
    e.printStackTrace();}
    boolean flag=true;
    while(flag)
    {
    try {   ch=br.read();//To read users input}
 catch (IOException e) {// TODO Auto-generated catch block
                e.printStackTrace();}
    if(ch=='x'){break;}
    try {   os.write(ch);//TO write to server's console }
 catch (IOException e) {// TODO Auto-generated catch block
        e.printStackTrace();}

try {   is.read(); //To read server's response  }
 catch (IOException e) {// TODO Auto-generated catch block
        e.printStackTrace();}
    }
        
}
    public static void main(String args[]) throws IOException
    {
        client sc=new client();
        sc.doEcho();
    }
}