package swing;
package swing;

import java.awt.Container;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class button1 extends JApplet implements ActionListener{
    Container c;  
 
    JButton ok = new JButton("ok");
    JButton select = new JButton("select");
    JButton exit = new JButton("exit");
    JButton hello = new JButton("hello");
    JTextField ans = new JTextField(15);
    
    public button1()
    {
        c = this.getContentPane();
        c.setLayout(null);
        ans.setBounds(625,400,90,35);
        ok.setBounds(400,500,70,40);
        select.setBounds(550,500,70,40);       
        exit.setBounds(700,500,70,40);         
        hello.setBounds(850,500,70,40);
        c.add(ans);c.add(ok);c.add(select);
        c.add(exit);c.add(hello);
        ok.addActionListener(this);
        select.addActionListener(this);
        exit.addActionListener(this);
        hello.addActionListener(this);
    }
    @Override
    public void actionPerformed(ActionEvent e) 
    {
        String str= e.getActionCommand();
        if(str.equals("ok"))
        {
            ans.setText("you click ok");
        }
        else if(str.equals("select"))
        {ans.setText("you click select");}  
        else if(str.equals("exit"))
        {ans.setText("you click exit");}
        else 
        {ans.setText("you click hello");}
    }
}