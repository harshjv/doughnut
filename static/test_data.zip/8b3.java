import java.rmi.*; 
import java.rmi.registry.*; 
import java.rmi.server.*; 
public class WordsServer { 
public static void main(String args[]) 
{ 
System.setSecurityManager(new RMISecurityManager()); 
try 
{ 
WordsImpl pim = new WordsImpl("//localhost/pno"); 
System.out.println("\nServer is ready...");
} 
catch(Exception e) { } 
} 
} 