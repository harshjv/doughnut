import java.rmi.Naming;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.StringTokenizer;

public class WordsImpl extends UnicastRemoteObject implements WordsInterface {
int totalCharacters= 0;
int count = 0;
int totalWords= 0;
public WordsImpl(String name) throws RemoteException
{
super();
try
{
Naming.rebind(name,this);
}
catch(Exception e) { }
}
@Override
public int countChar(String s) throws RemoteException {
StringTokenizer tokens = new StringTokenizer(s, " ");
while(tokens.hasMoreTokens()){
String token= tokens.nextToken();
for (int i = 0; i < s.length(); i++)
{
if (Character.isDigit(s.charAt(i)))
{
count++;
}
else
{
totalCharacters++;
}
}
totalWords++;
}
return totalCharacters;
}
@Override
public int countWords(String s) throws RemoteException {
return totalWords;
}
@Override
public int countDigits(String s) throws RemoteException {
return count;
}
}
