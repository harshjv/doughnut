public interface WordsInterface extends java.rmi.Remote 
{ 
int countChar(String s) throws java.rmi.RemoteException; 
int countWords(String s) throws java.rmi.RemoteException; 
int countDigits(String s) throws java.rmi.RemoteException; 
} 