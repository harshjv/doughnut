import java.rmi.*; 
import java.rmi.registry.*; 
import java.rmi.server.*; 
import java.io.DataInputStream; 
public class WordsClient { 
public static void main(String args[]) 
{ 
System.setSecurityManager(new RMISecurityManager()); 
try 
{ 
int chars,words,digits; 
String s; 
WordsInterface pi = (WordsInterface) Naming.lookup("//localhost/pno"); 
DataInputStream in = new DataInputStream(System.in);; 
System.out.print("Enter String and press Y to stop "); 
char ch; 
int i=0; 
s=in.readLine();
chars = pi.countChar(s); 
System.out.println("characters are :"+chars); 
digits = pi.countDigits(s); 
System.out.println("digits are :"+digits); 
words = pi.countWords(s); 
System.out.println("characters are :"+words); 
} 
catch(Exception e) { } 
} 
}