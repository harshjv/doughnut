package connectionless;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;

public class client {
    public static void main(String a[]) throws IOException
    {
        DatagramSocket ds=new DatagramSocket();
        byte b[]=null;
        byte b1[]=null;
        //DatagramSocket ds1=new DatagramSocket();
        while(true)
        {
            b=new byte[1024*2];
             b1=new byte[1024*2];
        InetAddress ip=InetAddress.getLocalHost();
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        String str =br.readLine();
        b= str.getBytes();
        
        DatagramPacket dp=new DatagramPacket(b,b.length, ip,8001);
        ds.send(dp);
        
        if(str.toLowerCase().contains("exit"))
        {
            
            System.out.println("bye....!!!!!!!");
            break;
        }
        DatagramPacket dp1=new DatagramPacket(b1,b1.length);
        ds.receive(dp1);
        String str1= new String(dp1.getData());
        System.out.println(str1);
        //System.out.println(str1.length());
        
        if(str1.toLowerCase().contains("exit"))
        {
            System.out.println("bye....!!!!!!!");
            break;
        }
        }
        ds.close();
    }
}