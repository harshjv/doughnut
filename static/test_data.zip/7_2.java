package connectionless;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.*;

public class server {
    
    public static void main(String a[]) throws IOException{
        DatagramSocket ds=new DatagramSocket(8001,InetAddress.getLocalHost());
        //DatagramSocket ds1=new DatagramSocket();
        byte b[]=null;
        byte b2[]=null;
        BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
        while(true)
        {
            b=new byte[2048];
            b2=new byte[2048];
            DatagramPacket dp=new DatagramPacket(b,b.length);
            ds.receive(dp);
            String str1= new String(dp.getData());
            System.out.println(str1);
            if(str1.toLowerCase().contains("exit"))
            {
                System.out.println("bye....!!!!!!c u later....");
                break;
            }
            System.out.println("Reply");
            String b1 =br.readLine();
            b2= b1.toUpperCase().getBytes();
            DatagramPacket dp1=new DatagramPacket(b2,b2.length,dp.getSocketAddress());
            ds.send(dp1);
            if(b1.equals("exit"))
            {
                System.out.println("bye....!!!!!!c u later....");
                
                break;
            }
            
        }
        ds.close();
    }
    }
