package swing;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;

public class cal extends JApplet implements ActionListener{
    Container c;  
    JLabel l1 = new JLabel();
    JLabel l2 = new JLabel();
    JLabel l3 = new JLabel();
    JTextField no1 = new JTextField(4); 
    JTextField no2 = new JTextField(4); 
    JTextField no3 = new JTextField(4); 
    JButton addd = new JButton("+");
    JButton subb = new JButton("-");
    JButton mull = new JButton("*");
    JButton divv = new JButton("/");
    
    public void init(){
        c = this.getContentPane();
        c.setLayout(null);
        l1.setText("Enter No 1:");
        l2.setText("Enter No 1:");
        l3.setText("Answer");
        l1.setForeground(Color.BLACK);
        l2.setForeground(Color.BLACK);
        l3.setForeground(Color.BLACK);
        l1.setBounds(525,200,90,35);
        no1.setBounds(625,200,90,35);
        l2.setBounds(525,270,90,35);
        no2.setBounds(625,270,90,35);
        l3.setBounds(525,400,90,35);
        no3.setBounds(625,400,90,35);
        addd.setBounds(400,500,70,40);
        subb.setBounds(550,500,70,40);       
        mull.setBounds(700,500,70,40);         
        divv.setBounds(850,500,70,40); 
        c.add(l1);
        c.add(no1);
        c.add(l2);
        c.add(no2);
        c.add(l3);
        c.add(no3);
        c.add(addd);
        c.add(subb);
        c.add(mull);
        c.add(divv);
        no1.addActionListener(this);
        no2.addActionListener(this);
        no3.addActionListener(this);
        addd.addActionListener(this);
        subb.addActionListener(this);
        mull.addActionListener(this);
        divv.addActionListener(this);     
    }
   
    @Override
    public void actionPerformed(ActionEvent ae){
       
        String str = ae.getActionCommand();
        int ans=1;
        
        if(no1.getText()!= "" && no2.getText() != ""){ 
            
            if(str.equals("+")){
            
                   ans = Integer.parseInt(no1.getText()) + Integer.parseInt(no2.getText());
            }
            else if(str.equals("-")){
                
                    ans = Integer.parseInt(no1.getText()) - Integer.parseInt(no2.getText());
            }
            else if(str.equals("*")){
                
                    ans =
 Integer.parseInt(no1.getText()) * Integer.parseInt(no2.getText());
            }
            else if(str.equals("/")){
                
                    ans = Integer.parseInt(no1.getText()) / Integer.parseInt(no2.getText());
            }
            System.out.println(ans);
            no3.setText(Integer.toString(ans));
       }
    }  
}